"""Pustaka pipeline eksperimen IKMS 2026: K2 (LLM), gerbang mutu (K3), HHEM, BM25, lembar penilai, analisis.
Dipakai oleh notebook Colab. Semua fungsi berbasis pandas; model eksternal disuntikkan dari notebook."""
import concurrent.futures as cf
import json
import os
import random
import re
import time

import numpy as np
import pandas as pd

PARTS_ID = {"problem": "Masalah", "cause": "Penyebab", "actions": "Tindakan", "result": "Hasil",
            "lessons": "Pelajaran"}
FACT_PARTS = ["problem", "cause", "actions", "result"]
CATEGORIES = ["equipment repair/failure", "waiting on weather", "waiting (non-weather)", "fishing/stuck pipe",
              "lost circulation", "well control", "sidetrack", "other"]

# ---------------------------------------------------------------- data
def load_events(path):
    ev = pd.read_parquet(path)
    ev["sentences"] = ev.sentences.map(json.loads)
    ev["k1"] = ev.k1.map(json.loads)
    return ev.set_index("event_id", drop=False)


def numbered(sents):
    return "\n".join(f"S{i}: {s}" for i, s in enumerate(sents, 1))


# ---------------------------------------------------------------- K2: LLM
SYSTEM = (
    "You extract lessons learned from one non-productive-time (NPT) event in an offshore drilling daily report. "
    "Use ONLY the numbered sentences provided. Never use outside knowledge, never guess, and never add numbers, "
    "equipment, causes, or durations that are not written in the sentences. Return valid JSON only."
)
USER_TMPL = """Event narrative (numbered sentences):
{narr}

Return JSON with exactly this structure:
{{
  "problem": [{{"text": "...", "sources": ["S1"]}}],
  "cause":   [{{"text": "...", "sources": ["S2"]}}],
  "actions": [{{"text": "...", "sources": ["S3", "S4"]}}],
  "result":  [{{"text": "...", "sources": ["S5"]}}],
  "lessons": [{{"text": "...", "based_on": ["problem_1", "actions_1"]}}],
  "key_facts": {{"problem_category": "<one of: {cats}>",
                "equipment_failure": "yes|no|unknown",
                "depth_m": <number or "unknown">}}
}}
Rules:
- Each item is ONE atomic factual statement in one short English sentence.
- "sources" lists every sentence ID that supports the item. Every item in problem, cause, actions, and result must cite at least one sentence.
- problem: 1-3 items. cause: 0-3 items; if no cause is written, use exactly [{{"text": "unknown", "sources": []}}]. actions: 1-5 items. result: 0-3 items; if no outcome is written, use exactly [{{"text": "unknown", "sources": []}}].
- lessons: 1-2 recommendations derived only from the facts above. "based_on" lists item IDs such as problem_1, cause_2, actions_3 (numbered by position, starting at 1). Lessons must not introduce new numbers or equipment.
- key_facts.depth_m: the depth of the event in metres only if written in the sentences, otherwise "unknown"."""


def build_messages(sents):
    return SYSTEM, USER_TMPL.format(narr=numbered(sents), cats=", ".join(CATEGORIES))


def make_caller(provider, model, api_key, base_url=None, max_tokens=1500):
    """Kembalikan fungsi call(system, user) -> teks. provider: 'openai' (termasuk API kompatibel OpenAI) atau 'anthropic'."""
    if provider == "anthropic":
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)

        def call(system, user):
            r = client.messages.create(model=model, max_tokens=max_tokens, temperature=0, system=system,
                                       messages=[{"role": "user", "content": user}])
            return "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
    else:
        from openai import OpenAI
        client = OpenAI(api_key=api_key, base_url=base_url) if base_url else OpenAI(api_key=api_key)

        def call(system, user):
            kw = dict(model=model, temperature=0, max_tokens=max_tokens,
                      messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
            try:
                r = client.chat.completions.create(response_format={"type": "json_object"}, **kw)
            except Exception:
                r = client.chat.completions.create(**kw)
            return r.choices[0].message.content
    return call


def run_k2(ev, call, cache_path, workers=8, retries=4, only=None):
    """Jalankan K2 untuk semua kejadian; hasil disimpan per baris di cache JSONL agar bisa dilanjutkan."""
    done = {}
    if os.path.exists(cache_path):
        for line in open(cache_path, encoding="utf-8"):
            r = json.loads(line)
            if r.get("ok"):
                done[r["event_id"]] = r
    todo = [e for e in ev.event_id if e not in done and (only is None or e in only)]
    print(f"Sudah ada {len(done)}, akan diproses {len(todo)} kejadian")

    def one(eid):
        system, user = build_messages(ev.at[eid, "sentences"])
        for t in range(retries):
            try:
                raw = call(system, user)
                parse_k2(raw, len(ev.at[eid, "sentences"]))  # validasi
                return {"event_id": int(eid), "ok": True, "raw": raw, "ts": time.time()}
            except Exception as ex:  # noqa: BLE001
                err = repr(ex)[:300]
                time.sleep(2 * (t + 1))
        return {"event_id": int(eid), "ok": False, "error": err}

    with open(cache_path, "a", encoding="utf-8") as f, cf.ThreadPoolExecutor(workers) as pool:
        for i, r in enumerate(pool.map(one, todo), 1):
            f.write(json.dumps(r) + "\n")
            f.flush()
            if r["ok"]:
                done[r["event_id"]] = r
            if i % 50 == 0:
                print(f"  {i}/{len(todo)}")
    failed = [e for e in todo if e not in done]
    print(f"Selesai: {len(done)} berhasil, {len(failed)} gagal {failed[:10]}")
    return {e: done[e]["raw"] for e in done}


def _extract_json(raw):
    raw = raw.strip()
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        raise ValueError("tidak ada JSON")
    return json.loads(m.group(0))


def _norm_ref(b):
    b = str(b).strip().lower().replace(" ", "_")
    for wrong, right in [("problems_", "problem_"), ("causes_", "cause_"), ("action_", "actions_"),
                         ("results_", "result_"), ("lesson_", "lessons_")]:
        if b.startswith(wrong):
            b = right + b[len(wrong):]
    return b


UNKNOWN = re.compile(r"^\s*(unknown|not (stated|specified|mentioned|reported)|none( stated)?)\W*$", re.I)


def parse_k2(raw, n_sent):
    d = _extract_json(raw)
    out = []
    for part in FACT_PARTS + ["lessons"]:
        items = d.get(part) or []
        if isinstance(items, dict):
            items = [items]
        for i, it in enumerate(items, 1):
            if isinstance(it, str):
                it = {"text": it}
            text = str(it.get("text", "")).strip()
            if not text:
                continue
            srcs = [s.strip().upper() for s in (it.get("sources") or []) if isinstance(s, str)]
            srcs = [s for s in srcs if re.fullmatch(r"S\d+", s) and 1 <= int(s[1:]) <= n_sent]
            out.append({"cid": f"{part}_{i}", "part": part, "text": text, "sources": srcs,
                        "based_on": [_norm_ref(b) for b in (it.get("based_on") or [])],
                        "unknown": bool(UNKNOWN.match(text))})
    kf = d.get("key_facts") or {}
    return out, kf


def claims_table(ev, k2_raw):
    rows, kf_rows = [], []
    for eid, e in ev.iterrows():
        for c in e.k1:
            rows.append({"event_id": eid, "cond": "K1", "cid": c["id"], "part": c["part"], "text": c["text"],
                         "sources": c["sources"], "based_on": [], "unknown": False})
        if eid in k2_raw:
            cl, kf = parse_k2(k2_raw[eid], len(e.sentences))
            for c in cl:
                rows.append({"event_id": eid, "cond": "K2", **c})
            kf_rows.append({"event_id": eid, **{f"llm_{k}": v for k, v in kf.items()}})
    return pd.DataFrame(rows), pd.DataFrame(kf_rows)


# ---------------------------------------------------------------- gerbang mutu
NUM = re.compile(r"\d+(?:[.,]\d+)*")


def _nums(text):
    out = set()
    for m in NUM.findall(text):
        out.add(m)
        out.add(m.replace(",", ""))
        out.add(m.replace(",", "."))
        try:
            out.add(str(float(m.replace(",", ""))))
            out.add(str(float(m.replace(",", "."))))
        except ValueError:
            pass
    return out


def _claim_nums(text):
    return [m for m in NUM.findall(text)]


def _entities(text, ent):
    t = text.lower()
    return {canon for canon, syns in ent.items() if any(re.search(rf"\b{re.escape(s)}\b", t) for s in syns)}


def source_text(claim, sents, claims_by_id=None):
    if claim["part"] == "lessons" and claims_by_id is not None:
        ids = set()
        for b in claim["based_on"]:
            c = claims_by_id.get(b)
            if c is not None:
                ids |= set(c["sources"])
        srcs = sorted(ids, key=lambda s: int(s[1:]))
    else:
        srcs = claim["sources"]
    return " ".join(sents[int(s[1:]) - 1] for s in srcs)


def lexical_ok(claim_text, src_text, ent):
    if not src_text.strip():
        return False
    sn = _nums(src_text)
    for n in _claim_nums(claim_text):
        if not ({n, n.replace(",", ""), n.replace(",", ".")} & sn):
            try:
                if str(float(n.replace(",", ""))) not in sn and str(float(n.replace(",", "."))) not in sn:
                    return False
            except ValueError:
                return False
    return _entities(claim_text, ent) <= _entities(src_text, ent)


def add_lexical_and_context(cl, ev, ent):
    """Tambah kolom context (kalimat rujukan) dan lex_ok untuk setiap klaim."""
    ctx, lex = [], []
    by_event = {eid: {r.cid: r for r in g.itertuples()} for eid, g in cl[cl.cond == "K2"].groupby("event_id")}
    for r in cl.itertuples():
        sents = ev.at[r.event_id, "sentences"]
        cmap = {k: {"sources": v.sources} for k, v in by_event.get(r.event_id, {}).items()} if r.cond == "K2" else None
        st = source_text({"part": r.part, "sources": r.sources, "based_on": r.based_on}, sents, cmap)
        ctx.append(st)
        lex.append(False if r.unknown else lexical_ok(r.text, st, ent))
    cl = cl.copy()
    cl["context"] = ctx
    cl["lex_ok"] = lex
    return cl


def apply_gate(cl, tau):
    """Kembalikan kolom passed untuk klaim K2 (Persamaan 1); klaim 'unknown' diteruskan apa adanya."""
    cl = cl.copy()
    k2 = cl.cond == "K2"
    fact = k2 & cl.part.isin(FACT_PARTS)
    cl = cl.reset_index(drop=True)
    k2, fact = k2.reset_index(drop=True), fact.reset_index(drop=True)
    vals = [None] * len(cl)
    for i in np.flatnonzero(fact.values):
        r = cl.iloc[i]
        vals[i] = True if r.unknown else bool(r.lex_ok and len(r.sources) > 0 and r.align_score >= tau)
    cl["passed"] = pd.Series(vals, dtype=object)
    passed = {(r.event_id, r.cid): bool(r.passed) for r in cl[fact].itertuples()}
    les = (k2 & (cl.part == "lessons")).values
    for i in np.flatnonzero(les):
        r = cl.iloc[i]
        vals[i] = bool(r.lex_ok and len(r.based_on) > 0 and all(passed.get((r.event_id, b), False) for b in r.based_on))
    cl["passed"] = pd.Series(vals, dtype=object)
    return cl


def choose_tau(lab):
    """lab: DataFrame klaim fakta K2 berlabel manusia (label D/S/T) dengan kolom align_score dan lex_ok.
    Positif = tidak didukung (S atau T). Prediksi tidak didukung = lex gagal atau align < tau."""
    y = lab.label.isin(["S", "T"]).values
    best = None
    grid = np.round(np.arange(0.05, 0.96, 0.01), 2)
    rows = []
    for t in grid:
        pred = (~lab.lex_ok.values) | (lab.align_score.values < t)
        tp, fp, fn = (pred & y).sum(), (pred & ~y).sum(), (~pred & y).sum()
        p = tp / (tp + fp) if tp + fp else 0.0
        r = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * p * r / (p + r) if p + r else 0.0
        rows.append((t, p, r, f1))
        if best is None or f1 > best[3] + 1e-12:
            best = (t, p, r, f1)
    return best[0], pd.DataFrame(rows, columns=["tau", "presisi", "recall", "f1"])


# ---------------------------------------------------------------- retensi, BM25, fakta kunci
def retention(ev, cl):
    test = ev[(ev.split == "test") & ev.eligible_source]
    k3 = cl[(cl.cond == "K2") & (cl.passed == True) & ~cl.unknown]  # noqa: E712
    have_p = set(k3[k3.part == "problem"].event_id)
    have_a = set(k3[k3.part == "actions"].event_id)
    kept = test.event_id.isin(have_p & have_a)
    return kept.mean(), kept


def _tok(t):
    return re.findall(r"[a-z0-9]+", str(t).lower())


def bm25_p5(ev, cl, k1=1.2, b=0.75):
    from rank_bm25 import BM25Okapi
    dev = ev[ev.split == "dev"]
    queries = ev[ev.query30]
    res = {}
    for cond in ["K1", "K2", "K3"]:
        if cond == "K3":
            sub = cl[(cl.cond == "K2") & (cl.passed == True)]  # noqa: E712
        else:
            sub = cl[cl.cond == cond]
        sub = sub[~sub.unknown]
        docs = sub.groupby("event_id").text.apply(" ".join)
        corpus = [_tok(docs.get(e, "")) or ["kosong"] for e in dev.event_id]
        bm = BM25Okapi(corpus, k1=k1, b=b)
        labels = dev.label.values
        p = []
        for q in queries.itertuples():
            sc = bm.get_scores(_tok(q.text))
            top = np.argsort(-sc, kind="stable")[:5]
            p.append(np.mean([labels[i] == q.label for i in top]))
        res[cond] = p
    return pd.DataFrame(res, index=queries.event_id)


DEPTH = re.compile(r"\b\d{2,5}(?:[.,]\d+)?\s?m\b(?![3²])", re.I)


def key_fact_accuracy(ev, kf):
    m = ev[ev.split == "test"].reset_index(drop=True).merge(kf, on="event_id", how="inner")
    cat = m.llm_problem_category.astype(str).str.strip().str.lower()
    acc_cat = (cat == m.key_category.str.lower())
    ef = m.llm_equipment_failure.astype(str).str.lower().str.strip()
    acc_ef = np.where(ef == "unknown", False, (ef == "yes") == m.key_equipment_failure)
    has_depth = m.text.fillna("").str.contains(DEPTH)
    dval = pd.to_numeric(m.llm_depth_m, errors="coerce")
    close = (dval - m.key_depth_m).abs() <= np.maximum(10, 0.05 * m.key_depth_m)
    acc_d = np.where(dval.isna(), ~has_depth, close.fillna(False))
    return pd.DataFrame({"event_id": m.event_id, "jenis_masalah": acc_cat, "kegagalan_peralatan": acc_ef,
                         "kedalaman": acc_d})


# ---------------------------------------------------------------- lembar Excel
def _fill_sheet(ws, blocks, start_row=7, with_generic=True):
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.worksheet.datavalidation import DataValidation
    thin = Side(style="thin", color="BFBFBF")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    ev_fill = PatternFill("solid", fgColor="DDEBF7")
    inp = PatternFill("solid", fgColor="FFF2CC")
    wrap = Alignment(wrap_text=True, vertical="top")
    for rng in list(ws.merged_cells.ranges):
        if rng.min_row >= start_row - 1:
            ws.unmerge_cells(str(rng))
    ws.delete_rows(start_row - 1, ws.max_row)
    r, n = start_row - 1, 0
    for b in blocks:
        narr = "\n".join(f"S{i}: {s}" for i, s in enumerate(b["sentences"], 1))
        for c, v in [(1, ""), (2, b["eid"]), (3, "NARASI\n" + narr)]:
            x = ws.cell(row=r, column=c, value=v)
            x.fill, x.alignment, x.border = ev_fill, wrap, box
            x.font = Font(name="Arial", size=10, bold=(c == 2))
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=9)
        ws.row_dimensions[r].height = min(409, 13.5 * (len(b["sentences"]) + 1) + sum(len(s) // 110 for s in b["sentences"]) * 13)
        r += 1
        for c in b["claims"]:
            n += 1
            vals = [n, b["eid"], c["rid"], c["bagian"], c["text"], "", "", "" if c["bagian"] == "Pelajaran" else "–", ""]
            for j, v in enumerate(vals, 1):
                x = ws.cell(row=r, column=j, value=v)
                x.font, x.alignment, x.border = Font(name="Arial", size=10), wrap, box
                if j in (6, 7, 9) or (j == 8 and c["bagian"] == "Pelajaran"):
                    x.fill = inp
            ws.row_dimensions[r].height = max(15, 13.5 * (len(c["text"]) // 60 + 1))
            r += 1
    ws.data_validations.dataValidation = []
    dv = DataValidation(type="list", formula1='"D,S,T"', allow_blank=True, showErrorMessage=True,
                        error="Isi dengan D, S, atau T.")
    dv2 = DataValidation(type="list", formula1='"Ya,Tidak"', allow_blank=True, showErrorMessage=True)
    ws.add_data_validation(dv)
    ws.add_data_validation(dv2)
    dv.add(f"F{start_row}:F{r + 5}")
    dv2.add(f"H{start_row}:H{r + 5}")
    ws["B3"] = f'=COUNTIF(F{start_row}:F{r},"D")+COUNTIF(F{start_row}:F{r},"S")+COUNTIF(F{start_row}:F{r},"T")'
    ws["D3"] = f'=SUMPRODUCT(((F{start_row}:F{r}="S")+(F{start_row}:F{r}="T"))*(G{start_row}:G{r}=""))'
    ws["E3"] = f"dari {n} klaim"
    return n


def make_rater_workbooks(ev, cl, event_ids, template, out_prefix, title, seed, include_k1=True):
    """Buat lembar penilai (klaim unik K1+K2 diacak, tanpa label kondisi) dan kuncinya."""
    from openpyxl import load_workbook
    rnd = random.Random(seed)
    eids = list(event_ids)
    rnd.shuffle(eids)
    blocks, key = [], []
    for i, eid in enumerate(eids, 1):
        tag = f"E{i:02d}"
        sub = cl[(cl.event_id == eid) & ((cl.cond == "K2") | (include_k1 & (cl.cond == "K1")))]
        uniq = {}
        for r in sub.itertuples():
            norm = re.sub(r"\W+", " ", r.text.lower()).strip()
            uniq.setdefault(norm, {"text": r.text, "part": r.part, "src": []})["src"].append((r.cond, r.cid))
        items = list(uniq.values())
        rnd.shuffle(items)
        claims = []
        for j, it in enumerate(items, 1):
            rid = f"{tag}-C{j:02d}"
            claims.append({"rid": rid, "text": it["text"], "bagian": PARTS_ID[it["part"]]})
            for cond, cid in it["src"]:
                key.append({"rid": rid, "eid_samaran": tag, "event_id": eid, "cond": cond, "cid": cid,
                            "part": it["part"]})
        blocks.append({"eid": tag, "sentences": ev.at[eid, "sentences"], "claims": claims})
    wb = load_workbook(template)
    if "Validasi_Audit" in wb.sheetnames:
        del wb["Validasi_Audit"]
    ws = wb["Penilaian"]
    ws["A1"] = title
    ws["A2"] = "Nilai setiap klaim hanya terhadap narasi di atasnya. Klaim diacak dan sumbernya disamarkan."
    n = _fill_sheet(ws, blocks)
    wb.active = wb.sheetnames.index("Penilaian")
    wb.save(f"{out_prefix}.xlsx")
    pd.DataFrame(key).to_csv(f"{out_prefix}_KUNCI_TIM_A.csv", index=False)
    return n, len(blocks)


def make_tau_workbook(ev, cl, event_ids, template, out_path, seed):
    """Lembar label untuk menentukan tau: hanya klaim fakta K2 (bukan 'unknown'), tanpa skor."""
    sub = cl[(cl.cond == "K2") & cl.part.isin(FACT_PARTS) & ~cl.unknown & cl.event_id.isin(list(event_ids))]
    sub = sub.assign(cond="K2only")
    tmp = sub.copy()
    tmp["cond"] = "K2"
    return make_rater_workbooks(ev, tmp, event_ids, template, out_path,
                                "Lembar label τ (15 kejadian validasi) – diisi Tim A", seed, include_k1=False)


def read_labels(path, sheet="Penilaian"):
    from openpyxl import load_workbook
    ws = load_workbook(path, data_only=True)[sheet]
    rows = []
    for r in ws.iter_rows(min_row=1, values_only=True):
        if r and isinstance(r[2], str) and re.fullmatch(r"E\d{2}-C\d{2}", r[2]):
            lab = (str(r[5]).strip().upper() if r[5] else "")
            rows.append({"rid": r[2], "label": lab if lab in ("D", "S", "T") else "", "alasan": r[6],
                         "generik": r[7] if r[7] in ("Ya", "Tidak") else ""})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- statistik
def cohen_kappa(a, b):
    a, b = np.asarray(a), np.asarray(b)
    cats = sorted(set(a) | set(b))
    po = np.mean(a == b)
    pe = sum(np.mean(a == c) * np.mean(b == c) for c in cats)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def holm(pvals):
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (len(p) - rank) * p[i])
        adj[i] = min(1.0, running)
    return adj


def bootstrap_ci(fn, n, B=10000, seed=2026):
    rng = np.random.default_rng(seed)
    vals = [fn(rng.integers(0, n, n)) for _ in range(B)]
    return np.nanpercentile(vals, [2.5, 97.5])


def analyse(cl, final_labels, keymap, ret_kept, p5, kfa, hhem_threshold=0.5):
    """final_labels: rid -> label akhir; keymap: DataFrame kunci (rid, event_id, cond, cid)."""
    from scipy import stats
    lab = keymap.merge(final_labels, on="rid")
    k2 = cl[cl.cond == "K2"].set_index(["event_id", "cid"])
    lab["passed"] = [k2.passed.get((e, c), np.nan) if cnd == "K2" else np.nan
                     for e, c, cnd in zip(lab.event_id, lab.cid, lab.cond)]
    lab["unsup"] = lab.label.isin(["S", "T"])
    rows = []
    for cond in ["K1", "K2", "K3"]:
        if cond == "K3":
            s = lab[(lab.cond == "K2") & (lab.passed == True)]  # noqa: E712
        else:
            s = lab[lab.cond == cond]
        u = s.groupby("event_id").unsup.mean().rename(cond)
        rows.append(u)
    Uall = pd.concat(rows, axis=1)
    U = Uall.dropna()
    out = {"n_kejadian_lengkap_3_kondisi": int(len(U)),
           "U_rerata_%": (Uall.mean() * 100).round(2).to_dict(),
           "n_kejadian_per_kondisi": Uall.notna().sum().to_dict()}
    fr = stats.friedmanchisquare(U.K1, U.K2, U.K3)
    out["friedman"] = {"chi2": round(float(fr.statistic), 3), "p": float(fr.pvalue), "n": int(len(U))}
    pairs = [("K1", "K2"), ("K1", "K3"), ("K2", "K3")]
    raw_p, zs, ns = [], [], []
    for a, b in pairs:
        d = Uall[[a, b]].dropna()
        try:
            w = stats.wilcoxon(d[a], d[b], zero_method="wilcox")
            pv = float(w.pvalue)
        except ValueError:
            pv = 1.0
        raw_p.append(pv)
        zs.append(stats.norm.isf(pv / 2) if pv < 1 else 0.0)
        ns.append(len(d))
    adj = holm(raw_p)
    out["wilcoxon_holm"] = {f"{a}-{b}": {"p_holm": float(p), "r": round(float(z / np.sqrt(n)), 3), "n": int(n)}
                            for (a, b), p, z, n in zip(pairs, adj, zs, ns)}
    d23 = Uall[["K2", "K3"]].dropna()
    R = lambda idx: (d23.K2.values[idx].mean() - d23.K3.values[idx].mean()) / d23.K2.values[idx].mean()  # noqa: E731
    out["U_K2_%_pasangan"] = round(100 * d23.K2.mean(), 2)
    out["U_K3_%_pasangan"] = round(100 * d23.K3.mean(), 2)
    out["R_%"] = round(100 * R(np.arange(len(d23))), 2)
    out["R_CI95_%"] = (100 * bootstrap_ci(R, len(d23))).round(2).tolist()
    kept = np.asarray(ret_kept, float)
    out["T_%"] = round(100 * kept.mean(), 2)
    out["T_CI95_%"] = (100 * bootstrap_ci(lambda i: kept[i].mean(), len(kept))).round(2).tolist()
    out["T_n_layak_uji"] = int(len(kept))
    sp = lab[(lab.cond == "K2")].merge(cl[cl.cond == "K2"][["event_id", "cid", "align_score", "unknown"]],
                                       on=["event_id", "cid"])
    sp = sp[sp.part.isin(FACT_PARTS) & ~sp.unknown & sp.align_score.notna()]
    rho = stats.spearmanr(sp.align_score, sp.label.map({"T": 0, "S": 1, "D": 2}))
    out["spearman"] = {"rho": round(float(rho.statistic), 3), "p": float(rho.pvalue), "n_klaim": int(len(sp))}
    out["P@5_rerata"] = p5.mean().round(3).to_dict()
    fr2 = stats.friedmanchisquare(p5.K1, p5.K2, p5.K3)
    w2 = stats.wilcoxon(p5.K3, p5.K2, zero_method="wilcox") if (p5.K3 != p5.K2).any() else None
    out["P@5_friedman_p"] = float(fr2.pvalue)
    out["P@5_K3vsK2_p"] = float(w2.pvalue) if w2 else 1.0
    if kfa is not None and len(kfa):
        out["fakta_kunci_akurasi_%"] = (kfa[["jenis_masalah", "kegagalan_peralatan", "kedalaman"]].mean() * 100).round(1).to_dict()
    if "hhem" in cl:
        h = {}
        for cond in ["K1", "K2", "K3"]:
            s = cl[(cl.cond == "K2") & (cl.passed == True)] if cond == "K3" else cl[cl.cond == cond]  # noqa: E712
            s = s[~s.unknown & s.hhem.notna()]
            h[cond] = {"rerata": round(float(s.hhem.mean()), 3), "tidak_konsisten_%": round(100 * float((s.hhem < hhem_threshold).mean()), 2),
                       "n": int(len(s))}
        out["hhem"] = h
    p23 = out["wilcoxon_holm"]["K2-K3"]["p_holm"]
    crit = {
        "1_R>=50%_dan_p<0.05": bool(out["R_%"] >= 50 and p23 < 0.05),
        "2_T>=90%": bool(out["T_%"] >= 90),
        "3_rho>=0.6": bool(out["spearman"]["rho"] >= 0.6),
        "4_P5_K3>K2_dan_p<0.05": bool(out["P@5_rerata"]["K3"] > out["P@5_rerata"]["K2"] and out["P@5_K3vsK2_p"] < 0.05),
    }
    out["kriteria"] = crit
    out["kriteria_tercapai"] = int(sum(crit.values()))
    return out, U


# ---------------------------------------------------------------- diskusi & validasi audit
def disagreement_sheet(p1, p2, template_path_out, raters_text=None):
    """Gabungkan dua lembar penilai; tulis Excel berisi klaim yang labelnya berbeda untuk didiskusikan.
    Kembalikan (kappa_biner, tabel gabungan)."""
    l1, l2 = read_labels(p1), read_labels(p2)
    m = l1.merge(l2, on="rid", suffixes=("_1", "_2"))
    kosong = m[(m.label_1 == "") | (m.label_2 == "")]
    if len(kosong):
        print(f"PERINGATAN: {len(kosong)} klaim belum berlabel, contoh {kosong.rid.head(5).tolist()}")
    m = m[(m.label_1 != "") & (m.label_2 != "")]
    kappa = cohen_kappa(m.label_1 == "D", m.label_2 == "D")
    beda = m[m.label_1 != m.label_2].copy()
    if raters_text is not None:
        beda = beda.merge(raters_text, on="rid", how="left")
    beda["label_akhir"] = ""
    beda.to_excel(template_path_out, index=False)
    print(f"kappa biner = {kappa:.3f} | klaim dinilai keduanya = {len(m)} | berbeda = {len(beda)}")
    return kappa, m


def final_labels(merged, resolved_path=None):
    """Label akhir: label yang sama dari kedua penilai, atau label_akhir hasil diskusi."""
    fin = merged.assign(label=np.where(merged.label_1 == merged.label_2, merged.label_1, ""))[["rid", "label"]]
    if resolved_path:
        r = pd.read_excel(resolved_path)[["rid", "label_akhir"]].dropna()
        r["label_akhir"] = r.label_akhir.astype(str).str.strip().str.upper()
        fin = fin.merge(r, on="rid", how="left")
        fin["label"] = np.where(fin.label == "", fin.label_akhir.fillna(""), fin.label)
        fin = fin[["rid", "label"]]
    belum = (fin.label == "").sum()
    if belum:
        print(f"PERINGATAN: {belum} klaim belum punya label akhir")
    return fin[fin.label.isin(["D", "S", "T"])]


def read_audit(path):
    from openpyxl import load_workbook
    ws = load_workbook(path, data_only=True)["Validasi_Audit"]
    rows = []
    for r in ws.iter_rows(min_row=7, values_only=True):
        if r[1] and re.fullmatch(r"V\d{3}", str(r[1])):
            norm = lambda v: {"YA": True, "TIDAK": False}.get(str(v).strip().upper(), None)  # noqa: E731
            rows.append({"ID": r[1], "P1": norm(r[5]), "P2": norm(r[6]), "P3": norm(r[7])})
    return pd.DataFrame(rows)


def audit_metrics(p1_path, p2_path, key_csv, resolved_csv=None):
    """Kappa antarpenilai dan presisi/recall aturan teks untuk tiga indikator audit."""
    a, b = read_audit(p1_path), read_audit(p2_path)
    key = pd.read_csv(key_csv)
    m = a.merge(b, on="ID", suffixes=("_1", "_2")).merge(key, on="ID")
    if resolved_csv:
        res = pd.read_csv(resolved_csv).set_index("ID")
    rule = {"P1": "aturan_P1_penyebab", "P2": "aturan_P2_ringkasan_menyebut", "P3": "aturan_P3_ada_tindakan"}
    out = {}
    for q, col in rule.items():
        d = m[m[f"{q}_1"].notna() & m[f"{q}_2"].notna()].copy()
        kap = cohen_kappa(d[f"{q}_1"], d[f"{q}_2"])
        d["manusia"] = np.where(d[f"{q}_1"] == d[f"{q}_2"], d[f"{q}_1"], None)
        if resolved_csv and q in res:
            d["manusia"] = [v if v is not None else res[q].get(i) for v, i in zip(d.manusia, d.ID)]
        d = d[d.manusia.notna()]
        y, pr = d.manusia.astype(bool).values, d[col].astype(bool).values
        tp, fp, fn = (y & pr).sum(), (~y & pr).sum(), (y & ~pr).sum()
        out[q] = {"kappa": round(kap, 3), "n_dinilai": int(len(d)),
                  "presisi_aturan": round(tp / (tp + fp), 3) if tp + fp else None,
                  "recall_aturan": round(tp / (tp + fn), 3) if tp + fn else None,
                  "beda_belum_diputus": int((m[f"{q}_1"].notna() & m[f"{q}_2"].notna()
                                                     & (m[f"{q}_1"] != m[f"{q}_2"])).sum()) if not resolved_csv else 0}
    return out
